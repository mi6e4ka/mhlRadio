function playButton(){
    let audio = document.getElementById("player");
    let button = document.getElementById("button");
    audio.play();
    button.innerHTML = "enjoy :)";
    setTimeout("button.remove()", 1000);
}
function getCurSongName() {
    let x = new XMLHttpRequest();
    x.open("GET", "http://myradio24.com/users/50521/status.json", true);
    x.onload = function (){
        let json = JSON.parse(x.responseText);
        document.getElementById("curSong").innerHTML=json.song;
        document.getElementById("curImg").src="http://myradio24.com/"+json.img;
        document.getElementById("nextSong").innerHTML=json.nextsongs;
    }
    x.send(null);
}
setInterval("getCurSongName();", 500);
